
import { Json } from "@/integrations/supabase/types";

export interface Comment {
  userId: string;
  userName: string;
  message: string;
  timestamp: string;
  userDetails?: {
    email?: string;
    name?: string;
    profileId: string;
  };
}

// Helper function to safely extract comments from JSON data
export function extractComments(data: Json | null): Comment[] {
  if (!data) return [];
  
  if (Array.isArray(data)) {
    return data as Comment[];
  }
  
  return [];
}

// Helper function to safely convert Comment[] to Json
export function commentsToJson(comments: Comment[]): Json {
  return comments as unknown as Json;
}

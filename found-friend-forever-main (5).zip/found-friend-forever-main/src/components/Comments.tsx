
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Form, FormField, FormItem, FormControl, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useForm } from "react-hook-form";
import { useAuth } from "@/contexts/AuthContext";
import { extractComments, commentsToJson, Comment } from "@/utils/commentUtils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface CommentsProps {
  itemId: string;
  reportedById: string;
}

interface CommentFormData {
  message: string;
}

export function Comments({ itemId, reportedById }: CommentsProps) {
  const [sending, setSending] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [ownerProfile, setOwnerProfile] = useState<{ email?: string; full_name?: string } | null>(null);
  const { user } = useAuth();
  
  const form = useForm<CommentFormData>({
    defaultValues: {
      message: ""
    }
  });

  useEffect(() => {
    if (reportedById) {
      fetchOwnerProfile();
    }
    
    fetchComments();
  }, [reportedById]);

  const fetchOwnerProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('email, full_name')
        .eq('id', reportedById)
        .single();
        
      if (error) throw error;
      setOwnerProfile(data);
    } catch (error) {
      console.error('Error fetching owner profile:', error);
    }
  };
  
  const fetchComments = async () => {
    try {
      const { data: itemData, error: fetchError } = await supabase
        .from('items')
        .select('comments')
        .eq('id', itemId)
        .single();
      
      if (fetchError) throw fetchError;
      
      const existingComments = extractComments(itemData.comments);
      setComments(existingComments);
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const onSubmit = async (formData: CommentFormData) => {
    if (!user) {
      toast.error("You must be logged in to comment.");
      return;
    }
    
    setSending(true);
    
    try {
      // Get existing comments first
      const { data: itemData, error: fetchError } = await supabase
        .from('items')
        .select('comments, title')
        .eq('id', itemId)
        .single();
      
      if (fetchError) throw fetchError;
      
      // Create new comment object with user details
      const newComment: Comment = {
        userId: user.id,
        userName: user.user_metadata?.name || user.email?.split('@')[0] || 'User',
        message: formData.message,
        timestamp: new Date().toISOString(),
        // Include additional user details for transparency
        userDetails: {
          email: user.email,
          name: user.user_metadata?.name,
          profileId: user.id
        }
      };
      
      // Get existing comments
      const existingComments = extractComments(itemData.comments);
      
      // Update with new comment prepended to array
      const updatedComments = [newComment, ...existingComments];
      
      const { error } = await supabase
        .from('items')
        .update({
          comments: commentsToJson(updatedComments),
          updated_at: new Date().toISOString()
        })
        .eq('id', itemId);
      
      if (error) throw error;
      
      // Create a notification for the item owner
      if (user.id !== reportedById) {
        const { error: notificationError } = await supabase
          .from('notifications')
          .insert({
            user_id: reportedById,
            type: 'comment',
            message: `New comment on your item: ${itemData.title}`,
            related_item: itemId,
            metadata: {
              commenter: {
                id: user.id,
                name: user.user_metadata?.name,
                email: user.email
              }
            },
            is_read: false
          });
          
        if (notificationError) {
          console.error("Error creating notification:", notificationError);
        }
      }
      
      setComments(updatedComments);
      toast.success("Comment posted!");
      form.reset();
    } catch (error) {
      console.error("Error posting comment:", error);
      toast.error("Failed to post comment. Please try again.");
    } finally {
      setSending(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Comments</h3>
        
        {ownerProfile?.full_name && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Item reported by:</span>
            <span className="font-medium">{ownerProfile.full_name}</span>
            {ownerProfile?.email && (
              <a 
                href={`mailto:${ownerProfile.email}`}
                className="inline-flex items-center gap-1 text-primary hover:underline"
              >
                <Mail className="h-3 w-3" />
                {ownerProfile.email}
              </a>
            )}
          </div>
        )}
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Textarea
                      placeholder={user ? "Add a comment..." : "Sign in to comment"}
                      className="resize-none"
                      disabled={sending || !user}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end">
              <Button type="submit" disabled={sending || !user}>
                {sending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Posting...
                  </>
                ) : (
                  "Post Comment"
                )}
              </Button>
            </div>
          </form>
        </Form>
        
        <Separator className="my-4" />
        
        <div className="space-y-4 max-h-[400px] overflow-y-auto">
          {comments.length > 0 ? (
            comments.map((comment, index) => (
              <div key={index} className="flex gap-3 py-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    {comment.userName.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{comment.userName}</p>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(comment.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm mt-1">{comment.message}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-muted-foreground py-4">
              No comments yet. Be the first to comment!
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

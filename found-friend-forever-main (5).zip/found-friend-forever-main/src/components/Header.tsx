
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { LogIn, MessageSquare, Plus, Search } from 'lucide-react';
import { ItemStatus } from "@/types";
import { useAuth } from "@/contexts/AuthContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { ThemeToggle } from "./ThemeToggle";
import NotificationBadge from './NotificationBadge';
import MobileNavigation from './navigation/MobileNavigation';
import UserMenu from './navigation/UserMenu';

const Header = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const isMobile = useIsMobile();
  const [isScrolled, setIsScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setIsScrolled(offset > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const navItems = [
    { title: 'Lost Items', path: '/items/lost', status: 'lost' as ItemStatus },
    { title: 'Found Items', path: '/items/found', status: 'found' as ItemStatus },
    { title: 'How It Works', path: '/how-it-works' },
  ];
  
  return (
    <header 
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled ? 'bg-background/80 backdrop-blur-md border-b' : 'bg-background'
      }`}
    >
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center">
          {isMobile && <MobileNavigation user={user} navItems={navItems} onSignOut={signOut} />}
          
          <Link to="/" className="flex items-center">
            <h1 className="font-heading text-xl font-bold">Found & Lost</h1>
          </Link>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className="text-sm font-medium transition-colors hover:text-primary"
            >
              {item.title}
            </Link>
          ))}
        </nav>
        
        <div className="flex items-center gap-2">
          <ThemeToggle />
          
          {user ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/messages')}
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
              
              <NotificationBadge />
              
              <Button
                variant="ghost"
                size="icon"
                className="hidden md:inline-flex"
                onClick={() => navigate('/search')}
              >
                <Search className="h-5 w-5" />
              </Button>

              <Button
                variant="outline"
                className="hidden md:inline-flex"
                onClick={() => navigate('/report')}
              >
                <Plus className="mr-2 h-4 w-4" /> Report an Item
              </Button>
              
              <UserMenu user={user} onSignOut={signOut} />
            </>
          ) : (
            <Button onClick={() => navigate('/auth')}>
              <LogIn className="mr-2 h-4 w-4" />
              Sign In
            </Button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;


import { Link } from 'react-router-dom';
import { Twitter, Facebook, Instagram } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-white dark:bg-card border-t mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img 
                src="/lovable-uploads/cbda0f84-581b-4e96-b4ff-cc1b64a734d7.png" 
                alt="IIIT Dharwad" 
                className="w-10 h-10"
              />
              <span className="font-heading font-bold text-xl text-iiit-blue">IIIT<span className="text-iiit-blue-dark">Dharwad</span></span>
            </Link>
            <p className="text-gray-600 dark:text-gray-400 mb-4 max-w-md">
              Indian Institute of Information Technology Dharwad. Our campus lost and found portal helps reconnect people with their misplaced belongings.
            </p>
            <div className="flex space-x-4 text-gray-600 dark:text-gray-400">
              <a href="#" className="hover:text-iiit-blue transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-iiit-blue transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-iiit-blue transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-600 dark:text-gray-400 hover:text-iiit-blue dark:hover:text-iiit-blue transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/items/lost" className="text-gray-600 dark:text-gray-400 hover:text-iiit-blue dark:hover:text-iiit-blue transition-colors">Lost Items</Link>
              </li>
              <li>
                <Link to="/items/found" className="text-gray-600 dark:text-gray-400 hover:text-iiit-blue dark:hover:text-iiit-blue transition-colors">Found Items</Link>
              </li>
              <li>
                <Link to="/report" className="text-gray-600 dark:text-gray-400 hover:text-iiit-blue dark:hover:text-iiit-blue transition-colors">Report Item</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="text-gray-600 dark:text-gray-400">
                IIIT Dharwad Campus
              </li>
              <li className="text-gray-600 dark:text-gray-400">
                Ittigatti Road, Karnataka
              </li>
              <li className="text-gray-600 dark:text-gray-400">
                Email: contact@iiitdharwad.ac.in
              </li>
              <li className="text-gray-600 dark:text-gray-400">
                Phone: +91-123-456-7890
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            © {currentYear} IIIT Dharwad. All rights reserved.
          </p>
          <p className="text-gray-600 dark:text-gray-400 text-sm flex items-center mt-4 md:mt-0">
            Lost & Found Portal
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


import { Link } from 'react-router-dom';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Item, statusColors, statusLabels, categoryIcons } from "@/types";
import { useState, useRef, useEffect } from 'react';
import { fadeInUp } from '@/lib/animations';
import { useAuth } from "@/contexts/AuthContext";
import ItemActions from './ItemActions';

interface ItemCardProps {
  item: Item;
}

const ItemCard = ({ item }: ItemCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();
  const isOwner = user && item.reportedBy?.id === user.id;

  useEffect(() => {
    if (cardRef.current) {
      fadeInUp(cardRef.current);
    }
  }, []);

  const formattedDate = new Date(item.date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div ref={cardRef} className="lost-item-card border group">
      <Link to={`/item/${item.id}`} className="block">
        <div className="aspect-square relative overflow-hidden">
          <div className="absolute top-2 left-2 z-10">
            <Badge className={`${statusColors[item.status]}`}>
              {statusLabels[item.status]}
            </Badge>
          </div>
          {item.images && item.images.length > 0 ? (
            <img
              src={item.images[0]}
              alt={item.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              onError={(e) => {
                e.currentTarget.src = '/placeholder.svg';
              }}
            />
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center text-4xl">
              {categoryIcons[item.category]}
            </div>
          )}
        </div>
        <div className="p-4">
          <h3 className="font-semibold text-lg line-clamp-1">{item.title}</h3>
          <div className="flex items-center text-sm text-gray-500 mt-1">
            <span className="line-clamp-1">{item.location}</span>
          </div>
          <p className="text-sm mt-2 text-gray-700 line-clamp-2">{item.description}</p>
          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-gray-500">{formattedDate}</span>
            <Link to={`/item/${item.id}`}>
              <Button
                variant="outline"
                size="sm"
              >
                View Details
              </Button>
            </Link>
          </div>
        </div>
      </Link>
      
      {isOwner && (
        <div className="p-4 border-t">
          <ItemActions item={item} />
        </div>
      )}
    </div>
  );
}

export default ItemCard;


import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ItemStatus } from "@/types";

interface ClaimDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  itemId: string;
  itemStatus: ItemStatus;
  onClaimSuccess?: () => void;
}

const ClaimDialog = ({ open, onOpenChange, itemId, itemStatus, onClaimSuccess }: ClaimDialogProps) => {
  const { user } = useAuth();
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('You must be logged in to claim an item');
      return;
    }
    
    if (!description.trim()) {
      toast.error('Please provide verification details');
      return;
    }
    
    setSubmitting(true);
    
    try {
      // Add claim to the claims table
      const { error: claimError, data: claimData } = await supabase
        .from('claims')
        .insert({
          item_id: itemId,
          user_id: user.id,
          description: description.trim(),
          status: 'pending'
        })
        .select();
      
      if (claimError) throw claimError;
      
      // Update the items table to mark it as claimed
      const { error: updateError } = await supabase
        .from('items')
        .update({
          claimed_by: user.id,
          status: itemStatus === 'lost' ? 'found' : 'claimed'
        })
        .eq('id', itemId);
      
      if (updateError) throw updateError;
      
      toast.success(
        itemStatus === 'lost' ? 'Found item reported successfully' : 'Claim submitted successfully', 
        {
          description: 'The item owner will be notified of your claim.'
        }
      );
      
      // Optional callback for parent component
      if (onClaimSuccess) {
        onClaimSuccess();
      }
      
      setDescription('');
      onOpenChange(false);
    } catch (error) {
      console.error('Error submitting claim:', error);
      toast.error('Failed to submit claim');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {itemStatus === 'lost' ? 'Found This Item?' : 'Claim This Item'}
          </DialogTitle>
          <DialogDescription>
            {itemStatus === 'lost' 
              ? 'Provide details about how you found this item to help the owner verify it belongs to them.' 
              : 'Provide details that prove you are the owner of this item.'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="verification" className="text-sm font-medium">
              Verification Details
            </label>
            <Textarea
              id="verification"
              placeholder={
                itemStatus === 'lost'
                  ? 'Describe where you found it, any distinguishing features, etc.'
                  : 'Describe distinctive features or details that only the owner would know.'
              }
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              required
              disabled={submitting}
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                itemStatus === 'lost' ? 'Report Found' : 'Submit Claim'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ClaimDialog;
